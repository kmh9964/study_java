package com.hanul.email;

public class EmailSender {

	// 이메일 전송 클래스
	// 프로젝트에 lib폴더를 만든다 --> 패키지에 가서 오른쪽 마우스-->폴더 선택-->lib만들어줌
	// javax.mail.jar, common-email-1.5.jar, activation-1.1.jar
	// 위의 3개의파일을 다운로드 받아서 lib 폴더에 넣는다.
	// 송신할 메일의 환경설정에서 SMPT 사용을 설정해야 한다.
	//  naver는 죄측하단 환경설정 -> pop3/IMAP설정 -> POP3/SMTP사용함 선택
	
	//  gmail은 상단 환경설정 -> 전달 및 pop3/IMAP -> IMAP 액세스:IMAP 사용으로 선택
	// 		  상단 내 계정 -> 로그인 및 보안 ->맨아래 연결된 앱 및 사이드 ->보안수준이 낮은  앱 허용 : 사용
	
	
	
	
	
	
	
	
	
	
}
