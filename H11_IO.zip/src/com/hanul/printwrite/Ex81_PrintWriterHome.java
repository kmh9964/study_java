package com.hanul.printwrite;

public class Ex81_PrintWriterHome {

	public static void main(String[] args) {
		//[과제]
		// printwrite 패키지에서 studentlist.txt 파일을 만들어서 패키지에 붙여넣는다.
		// 파일형태는 성명, 성별, 연락처, 이메일
		// 홍길동,남,010-1111-1111,hanul1@naver.com
		// 심청,여,010-1111-2222,hanul2@naver.com
		// 1. 문자열 22 개를 저장할  배열변수를 선언한다.
		// 2. BufferedReader 클래스를 사용해 studentlist.txt 파일에서 
		//		데이터를 한 줄씩 읽어온(readline()) 후 
		//   읽어온 데이터를 그대로 선언한 배열변수에 저장한다.
		// 3. 문자열 배열변수에 담긴 학생목록을 표의 형식으로 출력되게 
		//   src/printwrite/list.html 파일로 저장한다.

	}

}
