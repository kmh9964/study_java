package com.hanul.animal;

public class Ex60_animalDog extends Ex59_animal {

	//개
	//매소드: 먹는다, 잠을잔다,땅위를 달린다
	
	Ex60_animalDog(String kind) {
		super(kind);
		
	}
	
	void run() {
		System.out.println(kind + "가 땅위를 달린다.");
	}
	
	
	
}
