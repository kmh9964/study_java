package com.hanul.animal;

public class Ex62_animalMain  {

	public static void main(String[] args) {


		Ex60_animalDog dog = new Ex60_animalDog("강아지");
		dog.eat();
		dog.sleep();
		dog.run();
		System.out.println();
		
		Ex61_animalBird bird = new Ex61_animalBird("새");
		bird.eat();
		bird.sleep();
		bird.fly();
		
	
	}

}
