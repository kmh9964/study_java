package com.hanul.absta;

public class Ex67_animal2Main {

	public static void main(String[] args) {

		Ex64_dog dog = new Ex64_dog("발발이");
		dog.eat();
		dog.sleep();
		dog.sound();
		System.out.println();
		
		Ex65_cat cat = new Ex65_cat("야옹이");
		cat.eat();
		cat.sleep();
		cat.sound();
		System.out.println();
		
		Ex66_chicken chicken = new Ex66_chicken("꼬꼬");
		chicken.eat();
		chicken.sleep();
		chicken.sound();
		
		
		
		
		
		
	}

}
